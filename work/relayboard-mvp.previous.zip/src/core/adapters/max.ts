import type { MessengerAdapter, OutgoingMessage, SendResult } from "./types.js";

export class MaxAdapter implements MessengerAdapter {
  constructor(private readonly token: string) {}

  async send(destinationId: string, message: OutgoingMessage): Promise<SendResult> {
    const text = message.mediaUrl ? `${message.text}\n\n${message.mediaUrl}` : message.text;
    const response = await fetch(
      `https://platform-api2.max.ru/messages?chat_id=${encodeURIComponent(destinationId)}`,
      {
        method: "POST",
        headers: { authorization: this.token, "content-type": "application/json" },
        body: JSON.stringify({ text, format: "markdown" }),
      },
    );
    const body = await response.json() as { message?: { body?: { mid?: string }; mid?: string }; code?: string; message_id?: string };
    if (!response.ok) throw new Error(body.code || `MAX HTTP ${response.status}`);
    return { externalMessageId: String(body.message_id ?? body.message?.body?.mid ?? body.message?.mid ?? "unknown") };
  }
}
