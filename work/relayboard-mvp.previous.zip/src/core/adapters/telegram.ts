import type { MessengerAdapter, OutgoingMessage, SendResult } from "./types.js";

export class TelegramAdapter implements MessengerAdapter {
  constructor(private readonly token: string) {}

  async send(destinationId: string, message: OutgoingMessage): Promise<SendResult> {
    const method = message.mediaUrl ? "sendPhoto" : "sendMessage";
    const payload = message.mediaUrl
      ? { chat_id: destinationId, photo: message.mediaUrl, caption: message.text }
      : { chat_id: destinationId, text: message.text };
    const response = await fetch(`https://api.telegram.org/bot${this.token}/${method}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
    });
    const body = await response.json() as { ok?: boolean; result?: { message_id?: number }; description?: string };
    if (!response.ok || !body.ok) throw new Error(body.description || `Telegram HTTP ${response.status}`);
    return { externalMessageId: String(body.result?.message_id ?? "unknown") };
  }
}
