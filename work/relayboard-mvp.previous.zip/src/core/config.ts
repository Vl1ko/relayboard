import "dotenv/config";
import { z } from "zod";

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  PORT: z.coerce.number().default(3001),
  DATABASE_URL: z.string().url(),
  REDIS_URL: z.string().url(),
  ADMIN_API_KEY: z.string().min(12),
  APP_ENCRYPTION_KEY: z.string().min(16),
  WHATSAPP_BRIDGE_URL: z.string().url().default("http://localhost:3010"),
  WHATSAPP_BRIDGE_SECRET: z.string().min(12),
  WHATSAPP_SESSION_PATH: z.string().default("./data/whatsapp-session"),
  WHATSAPP_CHROMIUM_PATH: z.string().optional(),
});

export const config = schema.parse(process.env);
